
                 __________
    _____   __ __\______   \_____  _______  ______  ____ _______
   /     \ |  |  \|     ___/\__  \ \_  __ \/  ___/_/ __ \\_  __ \
  |  Y Y  \|  |  /|    |     / __ \_|  | \/\___ \ \  ___/ |  | \/
  |__|_|  /|____/ |____|    (____  /|__|  /____  > \___  >|__|
        \/                       \/            \/      \/

  Copyright (C) 2004-2020
  Ingo Berg


This sample demonstrates using muParsers C-interface. The C-Interface
is useful when interfacing muParser from different languages such
as C#. This sample is intended for use with the MS-Windows OS.

The sample should work with windows and linux.
